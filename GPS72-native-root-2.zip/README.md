# GPS 72 (native Android)
Garmin GPS 72 simulator using real GPS, real satellites (GnssStatus) and the phone's compass sensor.
Build APK: push to GitHub -> Actions tab -> "Build APK" -> download artifact GPS72-apk.
