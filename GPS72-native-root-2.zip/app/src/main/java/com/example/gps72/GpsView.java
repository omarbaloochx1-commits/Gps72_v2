package com.example.gps72;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.location.Location;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Handler;
import java.util.TimeZone;
import android.os.Looper;
import android.view.View;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class GpsView extends View {
    static class Wp { String n; double la, lo; Wp(String n, double a, double b) { this.n = n; la = a; lo = b; } }
    static class Ui { int t, m, sel, c; char[] n; }

    static final int[] ZM = {50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000};
    static final String CH = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    static final String[] UN = {"Metric", "Statute", "Nautical"};
    static final int L = 0, C = 1, R = 2;

    public boolean on;
    public int gerr;
    public double lat, lon, alt;
    public float spd, trk, acc, cmp;
    public long lastFix, cmpT;
    boolean hasAlt, bl = true;
    long t0, mt;
    int page, zi = 3, un, pf, con = 6, ms, go = -1;
    int bto, bp, dfm, nr, lf = 1, ofi = 1, sub, tb, si = -1, ts, tsel, mapOri, ptc;
    boolean t24 = true, eleFt, ofc, arrAl = true, hdgLn = true, accC = true, satUp, lostMsg;
    float tz = 99;
    public float decl;
    public String ver = "";
    public boolean fromGps;
    long lastGps;
    double odo, maxSpd, gsLat = 999, gsLon;
    long movT, stopT, totT, blUntil, lastOff;
    static final int[] BTS = {0, 15, 30, 60, 120};
    static final String[] BTN = {"Stays On", "15 Seconds", "30 Seconds", "1 Minute", "2 Minutes"};
    static final String[] BPN = {"Key and Message", "Message Only", "Off"};
    static final String[] DFN = {"Degrees", "Cardinal", "Mils"};
    static final String[] LFN = {"hddd.ddddd", "hddd mm.mmm", "hddd mm ss.s", "UTM", "Maidenhead"};
    static final String[] NRN = {"Auto (Mag)", "True"};
    static final int[] OFD = {50, 100, 200, 500, 1000};
    static final String[] TABS = {"Gen", "Time", "Units", "Loc", "Alarm"};
    static final String[] CARD = {"N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"};
    static class Trk { String n; ArrayList<double[]> p = new ArrayList<>(); boolean show; }
    ArrayList<Trk> saved = new ArrayList<>();
    ToneGenerator tg;
    char[] mn = new char[6], ml = new char[8], mo = new char[9];
    int mc;
    double trip;
    String msg = "";
    Ui ui;
    ArrayList<Wp> wps = new ArrayList<>();
    ArrayList<double[]> tk = new ArrayList<>();
    int sn;
    int[] sid = new int[0];
    float[] saz = new float[0], sel = new float[0], scn = new float[0];
    boolean[] sus = new boolean[0];
    Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);
    Canvas c;
    SharedPreferences sp;
    Handler h = new Handler(Looper.getMainLooper());

    public GpsView(Context x) {
        super(x);
        P.setTypeface(Typeface.MONOSPACE);
        sp = x.getSharedPreferences("g72", 0);
        un = sp.getInt("un", 0); pf = sp.getInt("pf", 0); con = sp.getInt("con", 6); bl = sp.getBoolean("bl", true);
        bto = sp.getInt("bto", 0); bp = sp.getInt("beep", 0); dfm = sp.getInt("dfm", 0); nr = sp.getInt("nr", 0); lf = sp.getInt("lf", 1); ofi = sp.getInt("ofi", 1);
        t24 = sp.getBoolean("t24", true); eleFt = sp.getBoolean("eleFt", false); ofc = sp.getBoolean("ofc", false); arrAl = sp.getBoolean("arr", true);
        hdgLn = sp.getBoolean("hdg", true); accC = sp.getBoolean("acc", true); mapOri = sp.getInt("mori", 0); tz = sp.getFloat("tz", 99); odo = sp.getFloat("odo", 0);
        loadTracks();
        try {
            for (String s : sp.getString("wps", "").split(";")) {
                if (s.isEmpty()) continue;
                String[] a = s.split(",");
                wps.add(new Wp(a[0], Double.parseDouble(a[1]), Double.parseDouble(a[2])));
            }
        } catch (Exception e) { wps.clear(); }
        h.postDelayed(new Runnable() { public void run() { tick(); invalidate(); h.postDelayed(this, 1000); } }, 1000);
    }

    void save() {
        StringBuilder b = new StringBuilder();
        for (Wp w : wps) b.append(w.n).append(',').append(w.la).append(',').append(w.lo).append(';');
        sp.edit().putInt("un", un).putInt("pf", pf).putInt("con", con).putBoolean("bl", bl).putString("wps", b.toString()).putInt("bto", bto).putInt("beep", bp).putInt("dfm", dfm).putInt("nr", nr).putInt("lf", lf).putInt("ofi", ofi).putBoolean("t24", t24).putBoolean("eleFt", eleFt).putBoolean("ofc", ofc).putBoolean("arr", arrAl).putBoolean("hdg", hdgLn).putBoolean("acc", accC).putInt("mori", mapOri).putFloat("tz", tz).putFloat("odo", (float) odo).apply();
    }

    // ---------- data in ----------
    public void onLoc(Location l) {
        long now = System.currentTimeMillis();
        boolean g = "gps".equals(l.getProvider());
        if (!g && now - lastGps < 15000) return;
        if (g) lastGps = now;
        fromGps = g;
        lat = l.getLatitude(); lon = l.getLongitude();
        hasAlt = l.hasAltitude(); if (hasAlt) alt = l.getAltitude();
        acc = l.getAccuracy(); spd = l.hasSpeed() ? l.getSpeed() : 0; lastFix = now; gerr = 0;
        if (l.hasBearing() && spd > 1 && now - cmpT > 2000) trk = l.getBearing();
        double[] last = tk.isEmpty() ? null : tk.get(tk.size() - 1);
        if (last == null || dist(last[0], last[1], lat, lon) > 4) {
            if (last != null) { double dd = dist(last[0], last[1], lat, lon); trip += dd; odo += dd; if (++ptc % 10 == 0) sp.edit().putFloat("odo", (float) odo).apply(); }
            tk.add(new double[]{lat, lon});
            if (tk.size() > 5000) tk.remove(0);
        }
        if (go >= 0 && go < wps.size() && dist(lat, lon, wps.get(go).la, wps.get(go).lo) < Math.max(15, acc)) {
            alarm("Arriving at Destination"); go = -1;
        }
        postInvalidate();
    }

    public void setCompass(float hd) {
        float d = ((hd - cmp + 540) % 360) - 180;
        cmp = cmpT == 0 ? hd : (cmp + d * 0.25f + 360) % 360;
        cmpT = System.currentTimeMillis();
        trk = cmp;
        postInvalidate();
    }

    public void setSats(int n, int[] id, float[] az, float[] el, float[] cn, boolean[] us) {
        sn = n; sid = id; saz = az; sel = el; scn = cn; sus = us; postInvalidate();
    }

    void toast(String s) { msg = s; mt = System.currentTimeMillis() + 2000; postInvalidate(); }

    // ---------- helpers ----------
    static double dist(double a, double b, double c, double d) { float[] r = new float[2]; Location.distanceBetween(a, b, c, d, r); return r[0]; }
    static double brg(double a, double b, double c, double d) { float[] r = new float[2]; Location.distanceBetween(a, b, c, d, r); return (r[1] + 360) % 360; }
    int fix() { return !on ? 0 : (System.currentTimeMillis() - lastFix < (fromGps ? 10000 : 60000) && lastFix > 0) ? (hasAlt ? 3 : 2) : 0; }
    String fd(double m) {
        if (un == 0) return m < 1000 ? String.format(Locale.US, "%.0fm", m) : String.format(Locale.US, m < 10000 ? "%.2fkm" : "%.1fkm", m / 1000);
        double f = m * 3.281;
        if (un == 1) return f < 1000 ? String.format(Locale.US, "%.0fft", f) : String.format(Locale.US, "%.2fmi", m / 1609.34);
        return m < 185 ? String.format(Locale.US, "%.0fft", f) : String.format(Locale.US, "%.2fnm", m / 1852);
    }
    String fs(double v) { return un == 0 ? String.format(Locale.US, "%.1fkm/h", v * 3.6) : un == 1 ? String.format(Locale.US, "%.1fmph", v * 2.237) : String.format(Locale.US, "%.1fkt", v * 1.944); }
    String fa(double m) { return !eleFt ? String.format(Locale.US, "%.0fm", m) : String.format(Locale.US, "%.0fft", m * 3.281); }
    String fl(double v, boolean la) {
        if (lastFix == 0) return "-----";
        if (lf == 3) { String[] u = utm(); return la ? u[0] : u[1]; }
        if (lf == 4) return la ? mh() : "";
        String hh = la ? (v >= 0 ? "N" : "S") : (v >= 0 ? "E" : "W");
        double a = Math.abs(v);
        int d = (int) a;
        String dd = String.format(Locale.US, la ? "%02d" : "%03d", d);
        if (lf == 0) return hh + " " + String.format(Locale.US, "%.5f", a) + "\u00B0";
        if (lf == 2) { double mn = (a - d) * 60; int m2 = (int) mn; return hh + " " + dd + "\u00B0" + String.format(Locale.US, "%02d'%04.1f\"", m2, (mn - m2) * 60); }
        return hh + " " + dd + "\u00B0" + String.format(Locale.US, "%06.3f", (a - d) * 60) + "'";
    }
    String ete() {
        if (go < 0 || go >= wps.size() || spd < 0.3) return "--:--:--";
        int s = (int) (dist(lat, lon, wps.get(go).la, wps.get(go).lo) / spd);
        return String.format(Locale.US, "%02d:%02d:%02d", s / 3600, s / 60 % 60, s % 60);
    }
    int ia() { return ((int) (255 * (0.4 + con * 0.06))) << 24; }
    void ink() { P.setColor(ia() | 0x14200C); }
    void bgc() { P.setColor(lit() ? 0xFFA9CC7E : 0xFF93A578); }
    void T(String s, float x, float y, float z, int al, boolean b) {
        P.setStyle(Paint.Style.FILL); P.setTextSize(z); P.setFakeBoldText(b);
        P.setTextAlign(al == 0 ? Paint.Align.LEFT : al == 1 ? Paint.Align.CENTER : Paint.Align.RIGHT);
        c.drawText(s, x, y + z * 0.8f, P);
    }
    void fr(float x, float y, float w, float hh) { P.setStyle(Paint.Style.FILL); c.drawRect(x, y, x + w, y + hh, P); }
    void sr(float x, float y, float w, float hh) { P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(1); c.drawRect(x, y, x + w, y + hh, P); }
    void ln(float a, float b, float x, float y) { P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(1); c.drawLine(a, b, x, y, P); }
    void circ(float x, float y, float r) { P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(1); c.drawCircle(x, y, r, P); }
    void row(int i, String s, boolean sel, float y0) {
        float y = y0 + i * 20;
        if (sel) { fr(2, y, 156, 18); bgc(); T(s, 6, y + 4, 11, L, false); ink(); } else T(s, 6, y + 4, 11, L, false);
    }
    float[] proj(double la, double lo) {
        double p = 60.0 / ZM[zi];
        double dx = (lo - lon) * Math.cos(Math.toRadians(lat)) * 111320, dy = (la - lat) * 110540;
        if (mapOri == 1) { double t = Math.toRadians(trk), x2 = dx * Math.cos(t) - dy * Math.sin(t), y2 = dx * Math.sin(t) + dy * Math.cos(t); dx = x2; dy = y2; }
        return new float[]{(float) (80 + dx * p), (float) (125 - dy * p)};
    }

    // ---------- batch 1 features ----------
    boolean lit() { return bl && (bto == 0 || System.currentTimeMillis() < blUntil); }
    void relight() { if (bl && bto > 0) blUntil = System.currentTimeMillis() + BTS[bto] * 1000L; }
    void beep(boolean key) {
        if (bp == 2 || (key && bp == 1)) return;
        try { if (tg == null) tg = new ToneGenerator(AudioManager.STREAM_SYSTEM, 60); tg.startTone(ToneGenerator.TONE_PROP_BEEP, key ? 40 : 250); } catch (Exception e) { }
    }
    void alarm(String m) { toast(m); beep(false); }
    void tick() {
        if (!on) return;
        long now = System.currentTimeMillis();
        int f = fix();
        if (f > 0) { totT++; if (spd > 0.5) { movT++; if (spd > maxSpd) maxSpd = spd; } else stopT++; }
        if (lastFix > 0 && f == 0 && !lostMsg) { alarm("Lost Satellite Reception"); lostMsg = true; }
        if (f > 0) lostMsg = false;
        if (ofc && f > 0 && go >= 0 && go < wps.size() && Math.abs(xtk()) > OFD[ofi] && now - lastOff > 30000) { alarm("Off Course"); lastOff = now; }
    }
    double xtk() {
        if (go < 0 || go >= wps.size() || gsLat > 900) return 0;
        Wp w = wps.get(go);
        double b1 = Math.toRadians(brg(gsLat, gsLon, w.la, w.lo)), b13 = Math.toRadians(brg(gsLat, gsLon, lat, lon)), d13 = dist(gsLat, gsLon, lat, lon) / 6371000.0;
        return Math.asin(Math.sin(d13) * Math.sin(b13 - b1)) * 6371000.0;
    }
    String dirS(double t) {
        double d = nr == 1 ? t : t - decl;
        d = ((d % 360) + 360) % 360;
        if (dfm == 1) return CARD[(int) Math.round(d / 22.5) % 16];
        if (dfm == 2) return String.format(Locale.US, "%dmil", (int) Math.round(d * 6400 / 360) % 6400);
        return String.format(Locale.US, "%d\u00B0", (int) Math.round(d) % 360);
    }
    TimeZone tzone() {
        if (tz > 90) return TimeZone.getDefault();
        int m = Math.round(tz * 60);
        return TimeZone.getTimeZone(String.format(Locale.US, "GMT%s%02d:%02d", m < 0 ? "-" : "+", Math.abs(m) / 60, Math.abs(m) % 60));
    }
    String hm(long ms, boolean sec) {
        SimpleDateFormat f = new SimpleDateFormat(t24 ? (sec ? "HH:mm:ss" : "HH:mm") : (sec ? "hh:mm:ss a" : "hh:mm a"), Locale.US);
        f.setTimeZone(tzone()); return f.format(new Date(ms));
    }
    String dt(long ms) { SimpleDateFormat f = new SimpleDateFormat("dd MMM yyyy", Locale.US); f.setTimeZone(tzone()); return f.format(new Date(ms)); }
    String hms(long s) { return String.format(Locale.US, "%d:%02d:%02d", s / 3600, s / 60 % 60, s % 60); }
    String[] utm() {
        double a = 6378137, fl2 = 1 / 298.257223563, k0 = 0.9996, e2 = fl2 * (2 - fl2), ep2 = e2 / (1 - e2);
        int zone = Math.min(60, (int) ((lon + 180) / 6) + 1);
        double lon0 = Math.toRadians((zone - 1) * 6 - 180 + 3), phi = Math.toRadians(lat), lam = Math.toRadians(lon);
        double N = a / Math.sqrt(1 - e2 * Math.sin(phi) * Math.sin(phi)), T2 = Math.tan(phi) * Math.tan(phi), C2 = ep2 * Math.cos(phi) * Math.cos(phi), A = Math.cos(phi) * (lam - lon0);
        double M = a * ((1 - e2 / 4 - 3 * e2 * e2 / 64 - 5 * e2 * e2 * e2 / 256) * phi - (3 * e2 / 8 + 3 * e2 * e2 / 32 + 45 * e2 * e2 * e2 / 1024) * Math.sin(2 * phi) + (15 * e2 * e2 / 256 + 45 * e2 * e2 * e2 / 1024) * Math.sin(4 * phi) - (35 * e2 * e2 * e2 / 3072) * Math.sin(6 * phi));
        double x = k0 * N * (A + (1 - T2 + C2) * A * A * A / 6 + (5 - 18 * T2 + T2 * T2 + 72 * C2 - 58 * ep2) * Math.pow(A, 5) / 120) + 500000;
        double y = k0 * (M + N * Math.tan(phi) * (A * A / 2 + (5 - T2 + 9 * C2 + 4 * C2 * C2) * Math.pow(A, 4) / 24 + (61 - 58 * T2 + T2 * T2 + 600 * C2 - 330 * ep2) * Math.pow(A, 6) / 720));
        if (lat < 0) y += 10000000;
        char band = "CDEFGHJKLMNPQRSTUVWX".charAt(Math.max(0, Math.min(19, (int) Math.floor((lat + 80) / 8))));
        return new String[]{zone + "" + band + " E" + (long) x, "N" + (long) y};
    }
    String mh() {
        double lo = lon + 180, la2 = lat + 90;
        char[] s = new char[6];
        s[0] = (char) ('A' + Math.min(17, (int) (lo / 20))); s[1] = (char) ('A' + Math.min(17, (int) (la2 / 10)));
        s[2] = (char) ('0' + Math.min(9, (int) ((lo % 20) / 2))); s[3] = (char) ('0' + Math.min(9, (int) (la2 % 10)));
        s[4] = (char) ('a' + Math.min(23, (int) ((lo % 2) * 12))); s[5] = (char) ('a' + Math.min(23, (int) ((la2 % 1) * 24)));
        return new String(s);
    }
    long[] sunTimes() {
        double jd = System.currentTimeMillis() / 86400000.0 + 2440587.5;
        double n = Math.round(jd - 2451545.0 + 0.0008), js = n - lon / 360.0;
        double M = (357.5291 + 0.98560028 * js) % 360, mr = Math.toRadians(M);
        double cc = 1.9148 * Math.sin(mr) + 0.02 * Math.sin(2 * mr) + 0.0003 * Math.sin(3 * mr);
        double lam = Math.toRadians((M + cc + 180 + 102.9372) % 360);
        double jt = 2451545.0 + js + 0.0053 * Math.sin(mr) - 0.0069 * Math.sin(2 * lam);
        double dec = Math.asin(Math.sin(lam) * Math.sin(Math.toRadians(23.44))), la = Math.toRadians(lat);
        double cw = (Math.sin(Math.toRadians(-0.833)) - Math.sin(la) * Math.sin(dec)) / (Math.cos(la) * Math.cos(dec));
        if (lastFix == 0 || Math.abs(cw) > 1) return new long[]{-1, -1};
        double w = Math.toDegrees(Math.acos(cw)) / 360.0;
        return new long[]{(long) ((jt - w - 2440587.5) * 86400000.0), (long) ((jt + w - 2440587.5) * 86400000.0)};
    }
    double[] moonInfo() {
        double jd = System.currentTimeMillis() / 86400000.0 + 2440587.5, syn = 29.530588853;
        double age = ((jd - 2451550.1) % syn + syn) % syn;
        return new double[]{age, (1 - Math.cos(2 * Math.PI * age / syn)) / 2};
    }
    String phaseName(double a) {
        return a < 1.85 ? "New Moon" : a < 7.38 ? "Waxing Crescent" : a < 9.23 ? "First Quarter" : a < 14.77 ? "Waxing Gibbous" : a < 16.61 ? "Full Moon" : a < 22.15 ? "Waning Gibbous" : a < 24.0 ? "Last Quarter" : a < 27.7 ? "Waning Crescent" : "New Moon";
    }
    double tlen(Trk t) { double d = 0; for (int i = 1; i < t.p.size(); i++) d += dist(t.p.get(i - 1)[0], t.p.get(i - 1)[1], t.p.get(i)[0], t.p.get(i)[1]); return d; }
    void saveTracks() {
        StringBuilder b = new StringBuilder();
        for (Trk t : saved) { b.append(t.n).append('~').append(t.show ? 1 : 0).append('~'); for (double[] q : t.p) b.append(String.format(Locale.US, "%.5f,%.5f;", q[0], q[1])); b.append('|'); }
        sp.edit().putString("trk", b.toString()).apply();
    }
    void loadTracks() {
        try {
            for (String s : sp.getString("trk", "").split("\\|")) {
                if (s.isEmpty()) continue;
                String[] a = s.split("~", 3);
                Trk t = new Trk(); t.n = a[0]; t.show = a[1].equals("1");
                for (String q : a[2].split(";")) { if (q.isEmpty()) continue; String[] c2 = q.split(","); t.p.add(new double[]{Double.parseDouble(c2[0]), Double.parseDouble(c2[1])}); }
                saved.add(t);
            }
        } catch (Exception e) { saved.clear(); }
    }
    void saveLog() {
        if (tk.size() < 2) { toast("Track log empty"); return; }
        if (saved.size() >= 10) { toast("Track memory full"); return; }
        Trk t = new Trk(); t.n = new SimpleDateFormat("MMdd-HHmm", Locale.US).format(new Date()); t.show = true;
        int st = Math.max(1, tk.size() / 1500);
        for (int i = 0; i < tk.size(); i += st) t.p.add(tk.get(i));
        saved.add(t); saveTracks(); toast("Track saved");
    }
    void restoreDefaults() { bto = 0; bp = 0; con = 6; t24 = true; tz = 99; eleFt = false; un = 0; dfm = 0; lf = 1; nr = 0; ofc = false; ofi = 1; arrAl = true; save(); toast("Defaults restored"); }
    void menuAct(int i) {
        if (i == 0) sub = 1; else if (i == 1) { sub = 2; ts = 0; } else if (i == 2) { ui = new Ui(); ui.t = 1; ui.m = 1; }
        else if (i == 3) startManual();
        else if (i == 4) sub = 3; else if (i == 5) { sub = 4; tb = 0; si = -1; } else if (i == 6) sub = 5;
        else if (i == 7) { tk.clear(); toast("Track cleared"); } else if (i == 8) { go = -1; toast("GOTO stopped"); }
        save();
    }
    static final int[] LC = {0, 2, 3, 5, 6, 8, 9, 10};
    static final int[] OC = {0, 2, 3, 4, 6, 7, 9, 10, 11};
    void startManual() {
        sub = 7; mc = 0;
        mn = String.format(Locale.US, "WPT%03d", wps.size() + 1).toCharArray();
        double la = lastFix > 0 ? lat : 0, lo = lastFix > 0 ? lon : 0;
        ml = dm(Math.abs(la), 2, la < 0 ? 'S' : 'N');
        mo = dm(Math.abs(lo), 3, lo < 0 ? 'W' : 'E');
    }
    char[] dm(double a, int dd, char h) {
        int d = (int) a;
        String m = String.format(Locale.US, "%06.3f", (a - d) * 60);
        if (m.startsWith("60")) { d++; m = "00.000"; }
        return (h + String.format(Locale.US, dd == 2 ? "%02d" : "%03d", d) + m.replace(".", "")).toCharArray();
    }
    void manualKey(String k, int dy) {
        int tot = 6 + 8 + 9;
        if (k.equals("left")) mc = (mc + tot - 1) % tot;
        else if (k.equals("right")) mc = (mc + 1) % tot;
        else if (dy != 0) {
            if (mc < 6) { int i = CH.indexOf(mn[mc]); mn[mc] = CH.charAt((i - dy + 36) % 36); }
            else if (mc < 14) {
                int j = mc - 6;
                if (j == 0) ml[0] = ml[0] == 'N' ? 'S' : 'N'; else ml[j] = (char) ('0' + ((ml[j] - '0') - dy + 10) % 10);
            } else {
                int j = mc - 14;
                if (j == 0) mo[0] = mo[0] == 'E' ? 'W' : 'E'; else mo[j] = (char) ('0' + ((mo[j] - '0') - dy + 10) % 10);
            }
        } else if (k.equals("enter")) {
            double mla = Double.parseDouble(new String(ml, 3, 2) + "." + new String(ml, 5, 3));
            double mlo = Double.parseDouble(new String(mo, 4, 2) + "." + new String(mo, 6, 3));
            double la = Double.parseDouble(new String(ml, 1, 2)) + mla / 60.0;
            double lo = Double.parseDouble(new String(mo, 1, 3)) + mlo / 60.0;
            if (ml[0] == 'S') la = -la;
            if (mo[0] == 'W') lo = -lo;
            if (mla >= 60 || mlo >= 60 || Math.abs(la) > 90 || Math.abs(lo) > 180) { toast("Invalid coordinates"); return; }
            String nm = new String(mn);
            wps.add(new Wp(nm, la, lo)); save(); sub = 0; toast("Saved " + nm);
        }
    }
    void drawManual() {
        T("NEW WAYPOINT", 80, 3, 10, C, true);
        T("Name", 4, 24, 8, L, false); T("Latitude", 4, 62, 8, L, false); T("Longitude", 4, 100, 8, L, false);
        for (int i = 0; i < 6; i++) mch(i, "" + mn[i], 4 + i * 14, 34);
        for (int j = 0; j < 8; j++) mch(6 + j, "" + ml[j], 4 + LC[j] * 11, 72);
        T("\u00B0", 4 + 4 * 11, 72, 13, L, true); T(".", 4 + 7 * 11, 72, 13, L, true); T("'", 4 + 11 * 11, 72, 13, L, true);
        for (int j = 0; j < 9; j++) mch(14 + j, "" + mo[j], 4 + OC[j] * 11, 110);
        T("\u00B0", 4 + 5 * 11, 110, 13, L, true); T(".", 4 + 8 * 11, 110, 13, L, true); T("'", 4 + 12 * 11, 110, 13, L, true);
        T("DDD\u00B0MM.mmm' (WGS84)", 80, 148, 8, C, false);
        T("\u25B2\u25BC change  \u25C4\u25BA move", 80, 196, 8, C, false); T("ENTER = save  QUIT = cancel", 80, 210, 8, C, false);
    }
    void mch(int idx, String ch, float x, float y) {
        if (idx == mc) { fr(x - 1, y - 1, 11, 17); bgc(); T(ch, x, y, 13, L, true); ink(); } else T(ch, x, y, 13, L, true);
    }
    String[] setupRows() {
        long now = System.currentTimeMillis();
        switch (tb) {
            case 0: return new String[]{"Backlight: " + BTN[bto], "Beeper: " + BPN[bp], "Contrast: " + con};
            case 1: return new String[]{"Format: " + (t24 ? "24 Hour" : "12 Hour"), "Zone: " + (tz > 90 ? "Auto" : String.format(Locale.US, "UTC%+.1f", tz)), "Time: " + hm(now, true), "Date: " + dt(now)};
            case 2: return new String[]{"Elev: " + (eleFt ? "Feet" : "Meters"), "Dist: " + UN[un], "Dir: " + DFN[dfm]};
            case 3: return new String[]{"Fmt: " + LFN[lf], "North: " + NRN[nr], String.format(Locale.US, "MagVar: %.1f\u00B0", decl)};
            default: return new String[]{"Off Course: " + (ofc ? "On" : "Off"), "Dist: " + fd(OFD[ofi]), "Arrival: " + (arrAl ? "On" : "Off")};
        }
    }
    void setupAct(int d) {
        if (tb == 0) { if (si == 0) bto = (bto + d + 5) % 5; else if (si == 1) bp = (bp + d + 3) % 3; else if (si == 2) con = Math.max(0, Math.min(10, con + d)); }
        else if (tb == 1) { if (si == 0) t24 = !t24; else if (si == 1) { tz = tz > 90 ? (d > 0 ? -12 : 14) : tz + 0.5f * d; if (tz > 14 || tz < -12) tz = 99; } }
        else if (tb == 2) { if (si == 0) eleFt = !eleFt; else if (si == 1) un = (un + d + 3) % 3; else if (si == 2) dfm = (dfm + d + 3) % 3; }
        else if (tb == 3) { if (si == 0) lf = (lf + d + 5) % 5; else if (si == 1) nr = (nr + 1) % 2; }
        else { if (si == 0) ofc = !ofc; else if (si == 1) ofi = (ofi + d + 5) % 5; else if (si == 2) arrAl = !arrAl; }
        relight(); save();
    }
    void subKey(String k, int dy) {
        if (k.equals("page")) { sub = 0; page = (page + 1) % 5; return; }
        if (k.equals("quit")) { sub = sub == 6 ? 2 : 0; return; }
        if (k.equals("menu")) {
            if (sub == 1 || sub == 2 || sub == 4 || sub == 6) { ui = new Ui(); ui.t = 3; ui.m = sub == 1 ? 1 : sub == 2 ? 2 : sub == 4 ? 3 : 4; }
            return;
        }
        if (sub == 2) {
            int n = 2 + saved.size();
            if (dy != 0) ts = Math.max(0, Math.min(n - 1, ts + dy));
            else if (k.equals("enter")) { if (ts == 0) saveLog(); else if (ts == 1) { tk.clear(); toast("Track log cleared"); } else { tsel = ts - 2; sub = 6; } }
        } else if (sub == 6) {
            if (k.equals("enter") && tsel < saved.size()) { saved.get(tsel).show = !saved.get(tsel).show; saveTracks(); }
        } else if (sub == 7) {
            manualKey(k, dy);
        } else if (sub == 4) {
            int n = setupRows().length;
            if (dy != 0) si = Math.max(-1, Math.min(n - 1, si + dy));
            else if (k.equals("left") || k.equals("right")) { if (si == -1) tb = (tb + (k.equals("left") ? 4 : 1)) % 5; else setupAct(k.equals("left") ? -1 : 1); }
            else if (k.equals("enter") && si >= 0) setupAct(1);
        }
    }
    String[] optItems() {
        switch (ui.m) {
            case 0:
                if (page == 0) return new String[]{"Orientation: " + (satUp ? "Track Up" : "North Up")};
                return new String[]{"Orientation: " + (mapOri == 1 ? "Track Up" : "North Up")};
            case 1: return new String[]{"Reset Trip", "Reset Max Speed", "Reset Odometer"};
            case 2: return new String[]{"Delete Saved Track", "Delete All Tracks"};
            case 3: return new String[]{"Restore Defaults"};
            default: return new String[]{"Delete Track"};
        }
    }
    void optKey(String k, int dy) {
        String[] o = optItems();
        if (k.equals("menu")) { if (ui.m == 0) { ui = null; page = 4; } else ui = null; return; }
        if (dy != 0) ui.sel = Math.max(0, Math.min(o.length - 1, ui.sel + dy));
        else if (k.equals("enter")) optAct(ui.sel);
    }
    void optAct(int i) {
        int m = ui.m;
        if (m == 0) { if (page == 0) satUp = !satUp; else mapOri ^= 1; save(); return; }
        ui = null;
        if (m == 1) { if (i == 0) { trip = 0; movT = 0; stopT = 0; totT = 0; toast("Trip reset"); } else if (i == 1) { maxSpd = 0; toast("Max speed reset"); } else { odo = 0; toast("Odometer reset"); } save(); }
        else if (m == 2) { if (i == 0 && ts >= 2 && ts - 2 < saved.size()) { saved.remove(ts - 2); ts = Math.max(0, ts - 1); } else if (i == 1) { saved.clear(); ts = 0; } saveTracks(); }
        else if (m == 3) restoreDefaults();
        else { if (tsel < saved.size()) saved.remove(tsel); saveTracks(); sub = 2; ts = 0; }
    }
    void drawOpts() {
        T("OPTIONS", 80, 3, 10, C, true);
        String[] o = optItems();
        for (int i = 0; i < o.length; i++) row(i, o[i], i == ui.sel, 22);
        T("ENTER select  MENU:" + (ui.m == 0 ? "main" : "close"), 80, 222, 8, C, false);
    }
    void drawMenu() {
        if (sub == 1) { drawTrip(); return; }
        if (sub == 2) { drawTracks(); return; }
        if (sub == 3) { drawSun(); return; }
        if (sub == 4) { drawSetup(); return; }
        if (sub == 5) { drawSys(); return; }
        if (sub == 6) { drawTInfo(); return; }
        if (sub == 7) { drawManual(); return; }
        T("MAIN MENU", 80, 3, 10, C, true);
        String[] it = {"Trip Computer", "Tracks", "Waypoints (" + wps.size() + ")", "New Waypoint", "Sun & Moon", "Setup", "System Info", "Clear Track", "Stop GOTO"};
        for (int i = 0; i < it.length; i++) row(i, it[i], i == ms, 16);
        T("ENTER select", 80, 208, 8, C, false); T("Garmin GPS 72  v" + ver, 80, 222, 8, C, false);
    }
    void drawTrip() {
        T("TRIP COMPUTER", 80, 2, 9, C, true);
        String[] lb = {"Trip Odom", "Stopped Time", "Moving Avg", "Moving Time", "Overall Avg", "Total Time", "Max Speed", "Odometer"};
        String[] v = {fd(trip), hms(stopT), fs(movT > 0 ? trip / movT : 0), hms(movT), fs(totT > 0 ? trip / totT : 0), hms(totT), fs(maxSpd), fd(odo)};
        for (int i = 0; i < 8; i++) { float x = 4 + (i % 2) * 80, y = 18 + (i / 2) * 50; T(lb[i], x, y, 8, L, false); T(v[i], x, y + 12, v[i].length() > 8 ? 10 : 12, L, true); }
        T("MENU: reset options", 80, 224, 8, C, false);
    }
    void drawTracks() {
        T("TRACKS", 80, 2, 10, C, true);
        T("Log: " + tk.size() + " pts  " + fd(trip), 80, 15, 8, C, false);
        int n = 2 + saved.size(), o = Math.max(0, Math.min(ts - 3, n - 8));
        for (int i = o; i < Math.min(n, o + 8); i++) row(i - o, i == 0 ? "Save Log" : i == 1 ? "Clear Log" : saved.get(i - 2).n + " " + fd(tlen(saved.get(i - 2))), i == ts, 26);
        T("MENU: options", 80, 224, 8, C, false);
    }
    void drawTInfo() {
        T("TRACK INFO", 80, 3, 10, C, true);
        if (tsel >= saved.size()) return;
        Trk t = saved.get(tsel);
        T("Name", 4, 24, 8, L, false); T(t.n, 4, 34, 12, L, true);
        T("Distance", 4, 58, 8, L, false); T(fd(tlen(t)), 4, 68, 12, L, true);
        T("Points", 4, 92, 8, L, false); T("" + t.p.size(), 4, 102, 12, L, true);
        T("Show on Map: " + (t.show ? "[X]" : "[ ]"), 4, 130, 10, L, true);
        T("ENTER: toggle  MENU: delete", 80, 222, 8, C, false);
    }
    void drawSun() {
        T("SUN & MOON", 80, 3, 10, C, true);
        long now = System.currentTimeMillis();
        T(dt(now), 80, 18, 9, C, false);
        long[] s = sunTimes();
        T("Sunrise  " + (s[0] < 0 ? "--:--" : hm(s[0], false)), 4, 40, 11, L, true);
        T("Sunset   " + (s[1] < 0 ? "--:--" : hm(s[1], false)), 4, 58, 11, L, true);
        if (s[0] >= 0) { long dl = (s[1] - s[0]) / 60000; T(String.format(Locale.US, "Day %dh %02dm", dl / 60, dl % 60), 4, 76, 10, L, false); }
        double[] m = moonInfo();
        P.setStyle(Paint.Style.FILL); P.setAlpha((int) (40 + 215 * m[1])); c.drawCircle(80, 128, 24, P); ink(); circ(80, 128, 24);
        T(phaseName(m[0]), 80, 160, 11, C, true);
        T(String.format(Locale.US, "Age %.1f d   %d%% lit", m[0], (int) Math.round(m[1] * 100)), 80, 176, 9, C, false);
        if (lastFix == 0) T("Waiting for GPS location", 80, 206, 8, C, false);
    }
    void drawSetup() {
        T("SETUP", 80, 1, 8, C, false);
        for (int i = 0; i < 5; i++) {
            float x = 2 + i * 31.5f;
            if (i == tb) { fr(x, 12, 30, 14); bgc(); T(TABS[i], x + 15, 15, 8, C, false); ink(); } else { sr(x, 12, 30, 14); T(TABS[i], x + 15, 15, 8, C, false); }
        }
        if (si == -1) fr(2, 28, 156, 2);
        String[] r = setupRows();
        for (int i = 0; i < r.length; i++) row(i, r[i], i == si, 34);
        T("\u25C4 \u25BA change  MENU: defaults", 80, 224, 8, C, false);
    }
    void drawSys() {
        T("SYSTEM INFO", 80, 3, 10, C, true);
        int u = 0; for (boolean b : sus) if (b) u++;
        T("GPS 72 (Android)", 4, 28, 11, L, true); T("Software v" + ver, 4, 46, 10, L, false);
        T("Unit ID " + String.format(Locale.US, "%08X", (Build.MODEL + Build.DEVICE).hashCode()), 4, 62, 10, L, false);
        T("Satellites: " + sn + "  Used: " + u, 4, 82, 10, L, false); T("Android " + Build.VERSION.RELEASE, 4, 98, 10, L, false);
    }

    @Override
    protected void onMeasure(int w, int hh) {
        int W = MeasureSpec.getSize(w);
        setMeasuredDimension(W, W * 3 / 2);
    }

    // ---------- drawing ----------
    @Override
    protected void onDraw(Canvas cv) {
        c = cv;
        int W = getWidth(), H = getHeight();
        float sc = Math.min(W / 160f, H / 240f);
        c.save();
        c.translate((W - 160 * sc) / 2, (H - 240 * sc) / 2);
        c.scale(sc, sc);
        c.clipRect(0, 0, 160, 240);
        draw();
        c.restore();
    }

    void draw() {
        P.setPathEffect(null);
        if (on) bgc(); else P.setColor(0xFF4A4D31);
        P.setStyle(Paint.Style.FILL); c.drawRect(0, 0, 160, 240, P);
        if (!on) return;
        ink();
        int f = fix();
        long now = System.currentTimeMillis();
        if (now - t0 < 2500) {
            T("GARMIN", 80, 70, 24, C, true); T("GPS 72", 80, 104, 18, C, true); T("Hand-held Navigator", 80, 140, 9, C, false);
            return;
        }
        if (page == 0) {
            T("SATELLITE", 80, 2, 8, C, false); T(hm(System.currentTimeMillis(), false), 2, 2, 8, L, false); T(fs(spd), 158, 2, 8, R, false);
            float cx = 80, cy = 70, r = 50;
            circ(cx, cy, r); circ(cx, cy, r / 2); ln(cx - r, cy, cx + r, cy); ln(cx, cy - r, cx, cy + r);
            T("N", cx, cy - r - 10, 8, C, false);
            for (int i = 0; i < sn; i++) {
                float q = (90 - sel[i]) / 90f * r;
                double an = Math.toRadians(saz[i] - (satUp ? trk : 0)); float x = cx + q * (float) Math.sin(an), y = cy - q * (float) Math.cos(an);
                if (sus[i]) { fr(x - 7, y - 5, 14, 10); bgc(); T("" + sid[i], x, y - 4, 8, C, false); ink(); }
                else { sr(x - 7, y - 5, 14, 10); T("" + sid[i], x, y - 4, 8, C, false); }
            }
            int cnt = Math.min(sn, 12);
            for (int i = 0; i < cnt; i++) {
                float x = 6 + i * 12.5f, hh = Math.min(scn[i], 50) * 0.9f;
                if (hh > 1) fr(x, 200 - hh, 9, hh); else fr(x, 199, 9, 1);
                T("" + sid[i], x + 4.5f, 203, 7, C, false);
            }
            fr(4, 196, 152, 1);
            T(f == 0 ? "Acquiring Satellites" : f == 2 ? "2D GPS Location" : "3D GPS Location", 80, 216, 10, C, true);
            T(gerr == 1 ? "Location permission denied" : gerr == 2 ? "GPS is turned off" : f > 0 ? (fromGps ? "REAL GPS  EPE " : "NETWORK  EPE ") + (int) acc + "m" : "Waiting for GPS...", 80, 229, 8, C, false);
        } else if (page == 1) {
            c.save(); c.clipRect(0, 12, 160, 226);
            Path pa = new Path();
            for (int i = 0; i < tk.size(); i++) { float[] q = proj(tk.get(i)[0], tk.get(i)[1]); if (i == 0) pa.moveTo(q[0], q[1]); else pa.lineTo(q[0], q[1]); }
            P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(1); P.setPathEffect(new DashPathEffect(new float[]{2, 2}, 0)); c.drawPath(pa, P); P.setPathEffect(null);
            for (Trk t : saved) { if (!t.show) continue; Path sp2 = new Path(); for (int i = 0; i < t.p.size(); i++) { float[] q = proj(t.p.get(i)[0], t.p.get(i)[1]); if (i == 0) sp2.moveTo(q[0], q[1]); else sp2.lineTo(q[0], q[1]); } P.setStyle(Paint.Style.STROKE); c.drawPath(sp2, P); }
            if (go >= 0 && go < wps.size()) { float[] q = proj(wps.get(go).la, wps.get(go).lo); P.setStrokeWidth(2); c.drawLine(80, 125, q[0], q[1], P); P.setStrokeWidth(1); }
            for (int i = 0; i < wps.size(); i++) {
                float[] q = proj(wps.get(i).la, wps.get(i).lo);
                Path d = new Path(); d.moveTo(q[0], q[1] - 5); d.lineTo(q[0] + 5, q[1]); d.lineTo(q[0], q[1] + 5); d.lineTo(q[0] - 5, q[1]); d.close();
                P.setStyle(i == go ? Paint.Style.FILL : Paint.Style.STROKE); c.drawPath(d, P);
                T(wps.get(i).n, q[0] + 7, q[1] - 4, 8, L, false);
            }
            c.save(); c.translate(80, 125); c.rotate(mapOri == 1 ? 0 : trk);
            Path ar = new Path(); ar.moveTo(0, -8); ar.lineTo(6, 7); ar.lineTo(0, 3); ar.lineTo(-6, 7); ar.close();
            P.setStyle(Paint.Style.FILL); c.drawPath(ar, P); c.restore(); c.restore();
            fr(0, 12, 160, 1); T(mapOri == 1 ? "TRK UP" : "N\u2191", 156, 15, 8, R, false);
            T(fl(lat, true) + " " + fl(lon, false), 3, 15, 7, L, false);
            fr(4, 230, 60, 2); fr(4, 227, 1, 5); fr(63, 227, 1, 5); T(fd(ZM[zi]), 68, 226, 8, L, false);
            if (go >= 0 && go < wps.size()) T("\u2192" + wps.get(go).n + " " + fd(dist(lat, lon, wps.get(go).la, wps.get(go).lo)), 158, 226, 8, R, false);
            else if (f == 0) T("NO FIX", 156, 226, 9, R, false);
        } else if (page == 3) {
            T("HIGHWAY", 80, 2, 8, C, false);
            if (go < 0 || go >= wps.size()) { T("No Active GOTO", 80, 100, 11, C, true); T("Press GOTO to select", 80, 120, 9, C, false); }
            else {
                Wp w = wps.get(go);
                double b = brg(lat, lon, w.la, w.lo), d = dist(lat, lon, w.la, w.lo), df = ((b - trk + 540) % 360) - 180;
                T("TO  " + w.n, 4, 14, 11, L, true); T("DST " + fd(d), 4, 30, 11, L, false);
                T("BRG " + dirS(b), 4, 46, 11, L, false); T("ETE " + ete(), 4, 62, 11, L, false); fr(0, 80, 160, 1);
                float vx = (float) (80 + Math.max(-70, Math.min(70, df * 1.6)));
                ln(20, 215, vx - 6, 100); ln(140, 215, vx + 6, 100);
                P.setPathEffect(new DashPathEffect(new float[]{6, 6}, 0)); ln(80, 215, vx, 100); P.setPathEffect(null); fr(0, 100, 160, 1);
                T(Math.abs(df) < 5 ? "ON COURSE" : df > 0 ? "TURN RIGHT " + (int) Math.abs(df) + "\u00B0" : "TURN LEFT " + (int) Math.abs(df) + "\u00B0", 80, 86, 9, C, true);
            }
            fr(0, 218, 160, 1); T("SPD " + fs(spd), 4, 224, 10, L, false); T("TRK " + dirS(trk), 156, 224, 10, R, false);
        } else if (page == 2) {
            T("POINTER", 80, 2, 8, C, false);
            boolean act = go >= 0 && go < wps.size();
            T("SPD " + fs(spd), 4, 12, 9, L, true); T("TRK " + dirS(trk), 156, 12, 9, R, true);
            float cx = 80, cy = 98, r = 42;
            circ(cx, cy, r);
            for (int a = 0; a < 360; a += 30) {
                double g = Math.toRadians(a - trk);
                float sn2 = (float) Math.sin(g), co = (float) -Math.cos(g);
                if (a % 90 == 0) T("" + "NESW".charAt(a / 90), cx + sn2 * (r - 9), cy + co * (r - 9) - 4, 9, C, true);
                else ln(cx + sn2 * (r - 4), cy + co * (r - 4), cx + sn2 * r, cy + co * r);
            }
            Path tr = new Path(); tr.moveTo(cx, cy - r - 6); tr.lineTo(cx + 5, cy - r); tr.lineTo(cx - 5, cy - r); tr.close(); P.setStyle(Paint.Style.FILL); c.drawPath(tr, P);
            if (act) {
                Wp w = wps.get(go);
                double b = brg(lat, lon, w.la, w.lo), d = dist(lat, lon, w.la, w.lo);
                c.save(); c.translate(cx, cy); c.rotate((float) (b - trk));
                Path pp = new Path(); pp.moveTo(0, -r + 6); pp.lineTo(7, 8); pp.lineTo(0, 3); pp.lineTo(-7, 8); pp.close(); P.setStyle(Paint.Style.FILL); c.drawPath(pp, P); c.restore();
                T("TO " + w.n, 4, 148, 10, L, true); T("DST " + fd(d), 4, 162, 10, L, false); T("BRG " + dirS(b), 84, 162, 10, L, false);
                T("ETE " + ete(), 4, 176, 10, L, false); T("XTK " + fd(Math.abs(xtk())), 84, 176, 10, L, false);
            } else T("No Active GOTO", 80, 146, 10, C, true);
            fr(0, 192, 160, 1); T(fl(lat, true), 80, 196, 10, C, true); T(fl(lon, false), 80, 210, 10, C, true); T("ALT " + fa(alt), 80, 225, 8, C, false);
        } else {
            drawMenu();
        }
        if (ui != null) {
            bgc(); fr(0, 0, 160, 240); ink();
            if (ui.t == 1) {
                T(ui.m == 1 ? "WAYPOINTS" : "GOTO WAYPOINT", 80, 3, 10, C, true);
                if (wps.isEmpty()) T("No waypoints", 80, 100, 10, C, false);
                int o = Math.max(0, Math.min(ui.sel - 4, wps.size() - 9));
                for (int i = o; i < Math.min(wps.size(), o + 9); i++) row(i - o, String.format("%-7s", wps.get(i).n) + fd(dist(lat, lon, wps.get(i).la, wps.get(i).lo)), i == ui.sel, 16);
                T(ui.m == 1 ? "ENTER:GOTO MENU:DELETE" : "ENTER:GOTO  QUIT:BACK", 80, 222, 8, C, false);
            } else if (ui.t == 2) {
                fr(0, 0, 160, 16); bgc(); T("MARK POSITION", 80, 3, 10, C, true); ink(); T("Name", 80, 50, 9, C, false);
                for (int i = 0; i < 6; i++) {
                    float x = 80 + (i - 2.5f) * 16;
                    if (i == ui.c) { fr(x - 8, 68, 16, 22); bgc(); T("" + ui.n[i], x, 70, 16, C, true); ink(); } else T("" + ui.n[i], x, 70, 16, C, true);
                }
                T(fl(lat, true), 80, 110, 10, C, false); T(fl(lon, false), 80, 124, 10, C, false);
                T("\u25B2\u25BC char  \u25C4\u25BA move", 80, 160, 9, C, false); T("ENTER = OK   QUIT = CANCEL", 80, 200, 8, C, false);
            } else drawOpts();
        }
        if (now < mt) { ink(); fr(10, 95, 140, 34); bgc(); T(msg, 80, 106, 10, C, true); }
    }

    // ---------- keys ----------
    void pwr() {
        on = !on;
        if (on) { t0 = System.currentTimeMillis(); page = 0; ui = null; sub = 0; relight(); }
        postInvalidate();
    }

    void mark(String n) { wps.add(new Wp(n, lat, lon)); save(); }

    public void press(String k, boolean lg) {
        if (k.equals("light") && lg) { pwr(); return; }
        if (!on) return;
        beep(true);
        if (System.currentTimeMillis() - t0 < 2500) t0 = 0;
        if (k.equals("light")) { bl = !lit(); relight(); save(); postInvalidate(); return; }
        relight();
        int dy = k.equals("up") ? -1 : k.equals("down") ? 1 : 0;
        if (ui != null) {
            if (k.equals("quit")) ui = null;
            else if (ui.t == 1) {
                int n = wps.size();
                if (dy != 0) ui.sel = Math.max(0, Math.min(n - 1, ui.sel + dy));
                else if (k.equals("enter") && n > 0) { go = ui.sel; gsLat = lat; gsLon = lon; ui = null; page = 1; toast("GOTO " + wps.get(go).n); }
                else if (k.equals("menu") && ui.m == 1 && n > 0) {
                    if (go == ui.sel) go = -1; else if (go > ui.sel) go--;
                    wps.remove(ui.sel); ui.sel = Math.max(0, ui.sel - 1); save();
                }
            } else if (ui.t == 3) { optKey(k, dy);
            } else {
                if (k.equals("left")) ui.c = Math.max(0, ui.c - 1);
                else if (k.equals("right")) ui.c = Math.min(5, ui.c + 1);
                else if (dy != 0) { int i = CH.indexOf(ui.n[ui.c]); ui.n[ui.c] = CH.charAt((i - dy + 36) % 36); }
                else if (k.equals("enter")) { String nm = new String(ui.n); mark(nm); ui = null; toast("Saved " + nm); }
            }
            postInvalidate(); return;
        }
        if (sub != 0) { subKey(k, dy); postInvalidate(); return; }
        if (k.equals("page")) page = (page + 1) % 5;
        else if (k.equals("quit")) page = (page + 4) % 5;
        else if (k.equals("menu")) {
            if (page == 4) page = 1;
            else if (page == 0 || page == 1) { ui = new Ui(); ui.t = 3; ui.m = 0; }
            else page = 4;
        } else if (k.equals("zin") && (page == 1 || page == 3)) zi = Math.max(0, zi - 1);
        else if (k.equals("zout") && (page == 1 || page == 3)) zi = Math.min(ZM.length - 1, zi + 1);
        else if (k.equals("goto")) {
            if (lg) {
                if (lastFix == 0) { toast("No GPS fix"); return; }
                mark("MOB"); go = wps.size() - 1; gsLat = lat; gsLon = lon; page = 1; toast("MOB - GOTO active");
            } else if (wps.isEmpty()) toast("No waypoints");
            else { ui = new Ui(); ui.t = 1; ui.m = 0; ui.sel = Math.max(0, go); }
        } else if (k.equals("enter")) {
            if (lg) {
                if (lastFix == 0) { toast("No GPS fix"); return; }
                ui = new Ui(); ui.t = 2; ui.n = String.format(Locale.US, "WPT%03d", wps.size() + 1).toCharArray();
                ui.c = 5;
            } else if (page == 4) menuAct(ms);
        } else if (page == 4) {
            if (dy != 0) ms = (ms + dy + 9) % 9;
        }
        postInvalidate();
    }
}
