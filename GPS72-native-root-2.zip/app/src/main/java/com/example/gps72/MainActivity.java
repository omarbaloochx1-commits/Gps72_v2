package com.example.gps72;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.GnssStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.LinearLayout;

public class MainActivity extends Activity {
    GpsView gv;
    LocationManager lm;
    SensorManager sm;
    Handler h = new Handler(Looper.getMainLooper());
    boolean locStarted = false;
    float decl = 0;

    LocationListener ll = new LocationListener() {
        public void onLocationChanged(Location l) {
            try {
                decl = new GeomagneticField((float) l.getLatitude(), (float) l.getLongitude(), (float) l.getAltitude(), System.currentTimeMillis()).getDeclination();
            } catch (Exception e) { }
            gv.decl = decl;
            gv.onLoc(l);
        }
        public void onStatusChanged(String p, int s, Bundle b) { }
        public void onProviderEnabled(String p) { gv.gerr = 0; gv.postInvalidate(); }
        public void onProviderDisabled(String p) { gv.gerr = 2; gv.postInvalidate(); }
    };

    GnssStatus.Callback gcb = new GnssStatus.Callback() {
        public void onSatelliteStatusChanged(GnssStatus s) {
            int n = Math.min(s.getSatelliteCount(), 24);
            int[] id = new int[n];
            float[] az = new float[n], el = new float[n], cn = new float[n];
            boolean[] us = new boolean[n];
            for (int i = 0; i < n; i++) {
                id[i] = s.getSvid(i);
                az[i] = s.getAzimuthDegrees(i);
                el[i] = s.getElevationDegrees(i);
                cn[i] = s.getCn0DbHz(i);
                us[i] = s.usedInFix(i);
            }
            gv.setSats(n, id, az, el, cn, us);
        }
    };

    SensorEventListener sl = new SensorEventListener() {
        public void onSensorChanged(SensorEvent e) {
            float[] r = new float[9], o = new float[3];
            SensorManager.getRotationMatrixFromVector(r, e.values);
            SensorManager.getOrientation(r, o);
            if (Math.abs(o[1]) > 1.0f) {
                float[] r2 = new float[9];
                SensorManager.remapCoordinateSystem(r, SensorManager.AXIS_X, SensorManager.AXIS_Z, r2);
                SensorManager.getOrientation(r2, o);
            }
            float hd = (float) Math.toDegrees(o[0]) + decl;
            gv.setCompass(((hd % 360) + 360) % 360);
        }
        public void onAccuracyChanged(Sensor s, int a) { }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        gv = new GpsView(this);
        try { gv.ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception e) { }
        float d = getResources().getDisplayMetrics().density;
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF2A2C2E);
        sv.setFillViewport(true);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setPadding((int) (10 * d), (int) (16 * d), (int) (10 * d), (int) (20 * d));
        LinearLayout dev = new LinearLayout(this);
        dev.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xFF262626, 0xFF0B0B0B});
        float t = 80 * d, bt = 46 * d;
        g.setCornerRadii(new float[]{t, t, t, t, bt, bt, bt, bt});
        g.setStroke((int) (2 * d), 0xFF333333);
        dev.setBackground(g);
        dev.setPadding((int) (14 * d), (int) (22 * d), (int) (14 * d), (int) (18 * d));
        KeypadView kv = new KeypadView(this);
        kv.cb = new KeypadView.KeyCb() {
            public void key(String k, boolean lg) { gv.press(k, lg); }
        };
        dev.addView(kv, new LinearLayout.LayoutParams(-1, -2));
        FrameLayout lcd = new FrameLayout(this);
        GradientDrawable lg = new GradientDrawable();
        lg.setColor(0xFF000000);
        lg.setCornerRadius(12 * d);
        lg.setStroke((int) (3 * d), 0xFF1A1A1A);
        lcd.setBackground(lg);
        int p = (int) (8 * d);
        lcd.setPadding(p, p, p, p);
        lcd.addView(gv, new FrameLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins((int) (26 * d), (int) (4 * d), (int) (26 * d), 0);
        dev.addView(lcd, lp);
        TextView br = new TextView(this);
        br.setText("GARMIN");
        br.setTextColor(0xFFDDDDDD);
        br.setTextSize(20);
        br.setTypeface(Typeface.DEFAULT_BOLD);
        br.setLetterSpacing(0.08f);
        br.setGravity(Gravity.CENTER);
        br.setPadding(0, (int) (10 * d), 0, 0);
        dev.addView(br, new LinearLayout.LayoutParams(-1, -2));
        wrap.addView(dev, new LinearLayout.LayoutParams(-1, -2));
        sv.addView(wrap, new ViewGroup.LayoutParams(-1, -2));
        setContentView(sv);
        boolean needLoc = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED;
        boolean needNot = Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED;
        if (needLoc || needNot) {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, "android.permission.POST_NOTIFICATIONS"}, 1);
            else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        }
    }

    @Override
    public void onRequestPermissionsResult(int c, String[] p, int[] r) {
        super.onRequestPermissionsResult(c, p, r);
        startLocation();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Sensor rv = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        if (rv != null) sm.registerListener(sl, rv, SensorManager.SENSOR_DELAY_UI);
        startLocation();
    }

    @Override
    protected void onPause() {
        super.onPause();
        sm.unregisterListener(sl);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { lm.removeUpdates(ll); lm.unregisterGnssStatusCallback(gcb); } catch (Exception e) { }
        try { stopService(new Intent(this, TrackService.class)); } catch (Exception e) { }
        locStarted = false;
    }

    @Override
    public void onBackPressed() {
        if (gv.on) moveTaskToBack(true); else super.onBackPressed();
    }

    @SuppressLint("MissingPermission")
    void startLocation() {
        if (locStarted) return;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            gv.gerr = 1;
            gv.postInvalidate();
            return;
        }
        gv.gerr = lm.isProviderEnabled(LocationManager.GPS_PROVIDER) ? 0 : 2;
        String[] pv = {LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER};
        for (String p : pv) {
            try { lm.requestLocationUpdates(p, 1000, 0, ll); } catch (Exception e) { }
        }
        try { lm.registerGnssStatusCallback(gcb, h); } catch (Exception e) { }
        long now = System.currentTimeMillis();
        for (String p : pv) {
            try {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && now - l.getTime() < 60000) gv.onLoc(l);
            } catch (Exception e) { }
        }
        locStarted = true;
        try {
            Intent i = new Intent(this, TrackService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        } catch (Exception e) { }
        gv.postInvalidate();
    }
}
